## You can find keras2ncnn tools here

[https://github.com/MarsTechHAN/keras2ncnn](https://github.com/MarsTechHAN/keras2ncnn)  
[https://github.com/azeme1/keras2ncnn](https://github.com/azeme1/keras2ncnn)

----
### From tensorflow 2.x, you can also export mlir and use mlir2ncnn which is maintained by the official.

The source code is located here: [https://github.com/Tencent/ncnn/tree/master/tools/mlir](https://github.com/Tencent/ncnn/tree/master/tools/mlir)  
For Chinese, you can refer the guide here [https://zhuanlan.zhihu.com/p/152535430](https://zhuanlan.zhihu.com/p/152535430)