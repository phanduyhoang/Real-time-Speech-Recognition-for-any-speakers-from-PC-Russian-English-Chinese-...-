see [quantized-int8-inference](../../docs/how-to-use-and-FAQ/quantized-int8-inference.md)
